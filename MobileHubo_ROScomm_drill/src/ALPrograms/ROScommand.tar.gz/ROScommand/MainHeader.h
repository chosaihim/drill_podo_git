#ifndef MAINHEADER_H
#define MAINHEADER_H
#include <QCoreApplication>

#include <alchemy/task.h>
#include "../../../share/Headers/RosCommand.h"

#include <iostream>
#include <string>
#include <sys/mman.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include "BasicFiles/ManualCAN.h"

#include "BasicFiles/joint.h"
#include "BasicFiles/taskmotion.h"
#include "BasicFiles/BasicMatrix.h"

#ifndef PI
#define PI			3.141592653589793
#endif
#ifndef D2R
#define D2R			1.745329251994330e-2
#endif
#ifndef R2D
#define R2D			5.729577951308232e1
#endif

#include "OMNImove.h"
using namespace std;
/* Debug data */
FILE *fp;
#define ROW 50000
#define COL 100
int     Save_Index;
double  Save_Data[COL][ROW];

enum{
    PUB_DONE = 0, PUB_START, PUB_onlyRIGHT, PUB_onlyLEFT, PUB_onlyWHEEL
};

const int TransNum[NUM_JOINTS] = {
    RSP, RSR, RSY, REB, RWY, RWP, RWY2,
    LSP, LSR, LSY, LEB, LWY, LWP, LWY2,
    WST, RWH, LWH, BWH
};
OMNIMOVE OMNImove;

int MAX_GRIPPER_CNT = 300;

int isTerminated;
int PODO_NO;
int PODO_NO_DAEMON = 0;
int __IS_WORKING = false;
int __IS_GAZEBO = false;
int WB_FLAG = false;

int FLAG_JointPublish = false;
int STATE_JointPublish = PUB_DONE;
int FLAG_Gripper = false;
int MODE_Gripper = 0;
int PARA_Gripper = 0;

int CheckMotionOwned();
void CatchSignals(int _signal);
int HasAnyOwnership();

void RBTaskThread(void *);
void RBFlagThread(void *);
int RBInitialize(void);



// Move Function //
void StartWBIKmotion(int _mode);
void ROS_Joint_Publish();
void ROS_Move_Joint();
void ROS_Move_WBIK();
void PushJointReference();
void SetMoveJoint();
void SetWBIK();
void GripperTH();

void CheckArguments(int argc, char *argv[]){
    int opt = 0;
    int podoNum = -1;
    while((opt = getopt(argc, argv, "g:p:")) != -1){
        switch(opt){
        case 'g':
            if(strcmp(optarg, "true")==0 || strcmp(optarg, "TRUE")==0){
                __IS_GAZEBO = true;
            }else if(strcmp(optarg, "false")==0 || strcmp(optarg, "FALSE")==0){
                __IS_GAZEBO = false;
            }else{
                FILE_LOG(logERROR) << optarg;
                FILE_LOG(logERROR) << "Invalid option for Gazebo";
                FILE_LOG(logERROR) << "Valid options are \"true\", \"TRUE\", \"false\", \"FALSE\"";
                FILE_LOG(logERROR) << "Use default value";
            }
            break;
        case 'p':
            podoNum = atoi(optarg);
            if(podoNum == 0){
                FILE_LOG(logERROR) << optarg;
                FILE_LOG(logERROR) << "Invalid option for AL";
                FILE_LOG(logERROR) << "Valid options are \"true\", \"TRUE\", \"false\", \"FALSE\"";
                FILE_LOG(logERROR) << "Use default value";
            }else{
                PODO_NO = podoNum;
            }
            break;
        case '?':
            if(optopt == 'g'){
                FILE_LOG(logERROR) << "Option for Gazebo";
                FILE_LOG(logERROR) << "Valid options are \"true\", \"TRUE\", \"false\", \"FALSE\"";
            }else if(optopt == 'p'){
                FILE_LOG(logERROR) << "Option for AL";
                FILE_LOG(logERROR) << "Valid options are \"Integer Values\"";
            }
        }
    }


    cout << endl;
    FILE_LOG(logERROR) << "===========AL Setting============";
    FILE_LOG(logWARNING) << argv[0];
    if(__IS_GAZEBO)     FILE_LOG(logWARNING) << "AL for Gazebo";
    else                FILE_LOG(logWARNING) << "AL for Robot";
    FILE_LOG(logWARNING) << "AL Number: " << PODO_NO;
    FILE_LOG(logERROR) << "=================================";
    cout << endl;
}

#endif
