/*
 *	This program is generated from drc-podoal-template.
 *
 *	This AL-Process will activated by "PODO_Daemon" with appropriate "AL-Number".
 *	The AL-Number is determined at Core_config.db file at Share folder.
 *	And the AL-Process needs this AL-Number as an input parameter.
 *	So trying to open the AL-Process without any input parameter will terminate the process.
 *
 *	Please check your PODO_AL_NAME and Core_Config.db file.
 *	Actually the PODO_AL_NAME is used for recognizing the certain process and making it unique.
 *	So the same name of file with different path is allowed if the PODO_AL_NAMEs are different.
 *	But we recommend you that gather all of your build file in one folder (check the Core_Config.db file).
 *
 *	You can change the period of real-time thread by changing "RT_TIMER_PERIOD_MS" as another value in "rt_task_set_periodic".
 *	Please do not change "RT_TIMER_PERIOD_MS" value in "typedef.h".
 *	You can also change the priority of the thread by changing 4th parameter of "rt_task_create".
 *	In this function you need to care about the name of thread (the name should be unique).
 *
 *	Please do not change the "RBInitialize" function and fore code of main().
 *	You may express your idea in while loop of main & real-time thread.
 *
 *	Each AL-Process has its own command structure in Shared Memory.
 *	So, it can have its own command set.
 *	Make sure that the command set of each AL-process start from over than 100.
 *	Under the 100 is reserved for common command set.
 *
 *	Now, you can do everything what you want..!!
 *	If you have any question about PODO, feel free to contact us.
 *	Thank you.
 *
 *
 *
 *	Jungho Lee		: jungho77@rainbow.re.kr
 *	Jeongsoo Lim	: yjs0497@kaist.ac.kr
 *	Okkee Sim		: sim2040@kaist.ac.kr
 *
 *	Copy Right 2014 @ Rainbow Co., HuboLab of KAIST
 *
 */



#include "MainHeader.h"
#define PODO_AL_NAME       "ROScommand"

using namespace std;
inline void pushData(doubles &tar, double var){
    tar.push_back(var);
    tar.pop_front();
}

pRBCORE_SHM_COMMAND     sharedCMD;
pRBCORE_SHM_REFERENCE   sharedREF;
pRBCORE_SHM_SENSOR      sharedSEN;
pUSER_SHM               userData;
pROS_SHM                sharedROS;

RT_TASK rtTaskCon;
RT_TASK rtFlagCon;
RT_TASK rtJoystickCon;

JointControlClass *joint;
TaskMotion      *WBmotion;

//r2p sharedROS->r2p;

int main(int argc, char *argv[])
{
    // Termination signal ---------------------------------
    signal(SIGTERM, CatchSignals);   // "kill" from shell
    signal(SIGINT, CatchSignals);    // Ctrl-c
    signal(SIGHUP, CatchSignals);    // shell termination
    signal(SIGKILL, CatchSignals);
    signal(SIGSEGV, CatchSignals);

    // Block memory swapping ------------------------------
    mlockall(MCL_CURRENT|MCL_FUTURE);

    CheckArguments(argc, argv);
    if(PODO_NO == -1){
        FILE_LOG(logERROR) << "Please check the AL Number";
        FILE_LOG(logERROR) << "Terminate this AL..";
        return 0;
    }

    // Initialize RBCore -----------------------------------
    if( RBInitialize() == -1 )
        isTerminated = -1;

    usleep(500*1000);

    // WBIK Initialize--------------------------------------
    WBmotion = new TaskMotion(sharedREF, sharedSEN, sharedCMD, joint);

    // User command cheking --------------------------------
    while(isTerminated == 0)
    {
        switch(sharedROS->R2P.ROS_CMD)
        {
        case CMD_MOVE_JOINT:
        {
            switch(sharedROS->R2P.ROS_MODE)
            {
            case MODE_JOINT_PUBLISH:
            {
                FLAG_JointPublish = true;
                break;
            }
            case MODE_MOVE_JOINT:
            {
                joint->RefreshToCurrentReference();
                joint->SetAllMotionOwner();
                usleep(500*1000);
                SetMoveJoint();
                sharedROS->R2P.ROS_MODE = MODE_BREAK;
                break;
            }
            case MODE_SET_WBIK:
            {
                joint->RefreshToCurrentReference();
                StartWBIKmotion(0);
                usleep(20*1000);
                joint->SetAllMotionOwner();
                SetWBIK();
                sharedROS->R2P.ROS_MODE = MODE_BREAK;
                break;
            }
            default:
            {
                FLAG_JointPublish = false;
//                ROS_Clean();
                break;
            }
            }

            sharedROS->R2P.ROS_CMD = CMD_NOTHING;
            break;
        }
        case CMD_MOVE_GRIPPER:
        {
            FLAG_Gripper = true;
            MODE_Gripper = sharedROS->R2P.ROS_MODE;
            PARA_Gripper = sharedROS->R2P.ROS_PARA_INT;
            break;
        }
        case CMD_MOVE_BASE:
        {
            FILE_LOG(logSUCCESS) << "Start Wheel Move" <<sharedROS->R2P.wheelmove.MoveX ;
            joint->RefreshToCurrentReference();
            joint->SetAllMotionOwnerWHEEL();
            OMNImove.StartOMNImove(sharedROS->R2P.wheelmove.MoveX,sharedROS->R2P.wheelmove.MoveY,sharedROS->R2P.wheelmove.ThetaDeg);
            sharedROS->R2P.ROS_CMD = CMD_NOTHING;
            break;
        }
        default:
            break;
        }
    }
    cout << ">>> Process RobotWorld is terminated..!!" << endl;
    return 0;
}

/************************************************************************************************************************/
void RBTaskThread(void *)
{
    while(isTerminated == 0)
    {
        ROS_Joint_Publish();
        GripperTH();
        OMNImove.OMNIThread();
        if(OMNImove.IsMovingWheel())
        {
            printf("RWHREF = %f\n",OMNImove.RWHinfo.Reference);
            joint->SetMoveJoint(LWH, OMNImove.LWHinfo.Reference, OMNImove.OMNIinfo.TickSec*1000, MOVE_ABSOLUTE);
            joint->SetMoveJoint(RWH, OMNImove.RWHinfo.Reference, OMNImove.OMNIinfo.TickSec*1000, MOVE_ABSOLUTE);
            joint->SetMoveJoint(BWH, OMNImove.BWHinfo.Reference, OMNImove.OMNIinfo.TickSec*1000, MOVE_ABSOLUTE);
        }
        if(WB_FLAG == true)
        {
            // Global whole body model
            WBmotion->updateAll();
            WBmotion->WBIK_UB();

            for(int i=RHY; i<=LAR; i++)
            {
                if(i!=BWH)
                    joint->SetJointRefAngle(i, WBmotion->Q_filt_34x1[idRHY+i-RHY]*R2D);
            }

            joint->SetJointRefAngle(WST, WBmotion->Q_filt_34x1[idWST]*R2D);

            joint->SetJointRefAngle(RSP, WBmotion->Q_filt_34x1[idRSP]*R2D);
            joint->SetJointRefAngle(RSR, WBmotion->Q_filt_34x1[idRSR]*R2D - OFFSET_RSR);
            joint->SetJointRefAngle(RSY, WBmotion->Q_filt_34x1[idRSY]*R2D);
            joint->SetJointRefAngle(REB, WBmotion->Q_filt_34x1[idREB]*R2D - OFFSET_ELB);
            joint->SetJointRefAngle(RWY, WBmotion->Q_filt_34x1[idRWY]*R2D);
            joint->SetJointRefAngle(RWP, WBmotion->Q_filt_34x1[idRWP]*R2D);
            joint->SetJointRefAngle(RWY2, WBmotion->Q_filt_34x1[idRWY2]*R2D);

            joint->SetJointRefAngle(LSP, WBmotion->Q_filt_34x1[idLSP]*R2D);
            joint->SetJointRefAngle(LSR, WBmotion->Q_filt_34x1[idLSR]*R2D - OFFSET_LSR);
            joint->SetJointRefAngle(LSY, WBmotion->Q_filt_34x1[idLSY]*R2D);
            joint->SetJointRefAngle(LEB, WBmotion->Q_filt_34x1[idLEB]*R2D - OFFSET_ELB);
            joint->SetJointRefAngle(LWY, WBmotion->Q_filt_34x1[idLWY]*R2D);
            joint->SetJointRefAngle(LWP, WBmotion->Q_filt_34x1[idLWP]*R2D);
            joint->SetJointRefAngle(LWY2, WBmotion->Q_filt_34x1[idLWY2]*R2D);

            if(!CheckMotionOwned())
                WB_FLAG = false;
        }
        joint->MoveAllJoint();
        rt_task_suspend(&rtTaskCon);
    }

}

void RBFlagThread(void *)
{
    rt_task_set_periodic(NULL, TM_NOW, 300*1000);        // 300 usec

    while(isTerminated == 0)
    {
        rt_task_wait_period(NULL);

        //if(HasAnyOwnership()){
            if(sharedCMD->SYNC_SIGNAL[PODO_NO] == true){
                joint->JointUpdate();
                rt_task_resume(&rtTaskCon);
            }
       // }
    }
}

void ROS_Clean()
{

}

void GripperTH()
{
    if(FLAG_Gripper == true)
    {
        joint->RefreshToCurrentReference();
        joint->SetAllMotionOwner();
        switch(MODE_Gripper)
        {
        case GRIPPER_STOP:
        {
            printf("gripper stop\n");
            joint->SetJointRefAngle(RHAND, 0);
            joint->SetJointRefAngle(LHAND, 0);
            sharedROS->R2P.ROS_CMD = CMD_NOTHING;
            FLAG_Gripper = false;
            break;
        }
        case GRIPPER_OPEN:
        {
            static int gripper_cnt = 0;
            if(gripper_cnt > MAX_GRIPPER_CNT)
            {
                FILE_LOG(logINFO) << "Gripper open done";
                sharedROS->R2P.ROS_MODE = GRIPPER_STOP;
                sharedROS->R2P.ROS_PARA_INT = GRIPPER_BOTH;
                gripper_cnt = 0;
                break;
            }
            printf("gripper_cnt = %d\n",gripper_cnt);

            if(PARA_Gripper == GRIPPER_RIGHT)
            {//open only right gripper
                joint->SetJointRefAngle(RHAND, -130);
            } else if(PARA_Gripper == GRIPPER_LEFT)
            {//open only left gripper
                joint->SetJointRefAngle(LHAND, -130);
            } else
            {//open both gripper
                joint->SetJointRefAngle(RHAND, -130);
                joint->SetJointRefAngle(LHAND, -130);
            }

            gripper_cnt++;
            break;
        }
        case GRIPPER_CLOSE:
        {
            static int gripper_cnt = 0;
            if(gripper_cnt > MAX_GRIPPER_CNT)
            {
                FILE_LOG(logINFO) << "Gripper close done";
                sharedROS->R2P.ROS_MODE = GRIPPER_STOP;
                sharedROS->R2P.ROS_PARA_INT = GRIPPER_BOTH;
                gripper_cnt = 0;
                break;
            }
            printf("gripper_cnt = %d\n",gripper_cnt);
            if(PARA_Gripper == GRIPPER_RIGHT)
            {//close only right gripper
                joint->SetJointRefAngle(RHAND, 130);
            } else if(PARA_Gripper == GRIPPER_LEFT)
            {//close only left gripper
                joint->SetJointRefAngle(LHAND, 130);
            } else
            {//close both gripper
                joint->SetJointRefAngle(RHAND, 130);
                joint->SetJointRefAngle(LHAND, 130);
            }
            gripper_cnt++;
            break;
        }
        }
    }
}

void ROS_Joint_Publish()
{
    if(FLAG_JointPublish == true)
    {
        switch(STATE_JointPublish)
        {
        case PUB_DONE:
        {//First call
            joint->RefreshToCurrentReference();
            joint->SetAllMotionOwner();
            usleep(500*1000);


            FILE_LOG(logSUCCESS) << "JOINT PUBLISH START!!!";
            STATE_JointPublish = PUB_START;

            break;
        }
        case PUB_START:
        {
            PushJointReference();
            break;
        }
        }
    }else if(FLAG_JointPublish == false && STATE_JointPublish != PUB_DONE)
    {
        FILE_LOG(logSUCCESS) << "JOINT PUBLISH DONE!!!";
        STATE_JointPublish = PUB_DONE;
    }
}

void PushJointReference()
{
    for(int i=0;i<NUM_JOINTS;i++)
    {
        if(sharedROS->R2P.joint[i].ONOFF_control == CONTROL_ON)
        {
            double _ref = sharedROS->R2P.joint[i].reference;
            if(i==rosREB || i==rosLEB)
            {
                _ref += 20.0;
            }
            if(i==rosRSR) _ref += 15.0;
            if(i==rosLSR) _ref -= 15.0;
            joint->SetJointRefAngle(TransNum[i], _ref);

        }
    }
}

void SetMoveJoint()
{
    FILE_LOG(logSUCCESS) << "MOVE JOINT START!!!";
    for(int i=0;i<NUM_JOINTS;i++)
    {
        if(sharedROS->R2P.joint[i].ONOFF_control == CONTROL_ON)
        {
            joint->SetMoveJoint(TransNum[i], sharedROS->R2P.joint[i].reference, sharedROS->R2P.joint[i].GoalmsTime, MODE_ABSOLUTE);
        }
    }
}

void SetWBIK()
{
    FILE_LOG(logSUCCESS) << "MOVE WBIK START!!!";

    int tempNum = RIGHT_HAND;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
        WBmotion->addRHPosInfo(sharedROS->R2P.wbik[tempNum].Goal_pos[0], sharedROS->R2P.wbik[tempNum].Goal_pos[1], sharedROS->R2P.wbik[tempNum].Goal_pos[2], sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    if(sharedROS->R2P.wbik[tempNum].ONOFF_moveori == CONTROL_ON)
    {
        doubles tempQuat(4);
        for(int i=0;i<4;i++)
        {
            tempQuat[i] = sharedROS->R2P.wbik[tempNum].Goal_quat[i];
        }
        WBmotion->addRHOriInfo(tempQuat, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    }

    tempNum = LEFT_HAND;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
        WBmotion->addLHPosInfo(sharedROS->R2P.wbik[tempNum].Goal_pos[0], sharedROS->R2P.wbik[tempNum].Goal_pos[1], sharedROS->R2P.wbik[tempNum].Goal_pos[2], sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    if(sharedROS->R2P.wbik[tempNum].ONOFF_moveori == CONTROL_ON)
    {
        doubles tempQuat(4);
        for(int i=0;i<4;i++)
        {
            tempQuat[i] = sharedROS->R2P.wbik[tempNum].Goal_quat[i];
        }
        WBmotion->addLHOriInfo(tempQuat, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    }

    tempNum = PEL;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
    {
        WBmotion->addCOMInfo(sharedROS->R2P.wbik[tempNum].Goal_pos[0], sharedROS->R2P.wbik[tempNum].Goal_pos[1], sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
        WBmotion->addPELPosInfo(sharedROS->R2P.wbik[tempNum].Goal_pos[2], sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    }
    if(sharedROS->R2P.wbik[tempNum].ONOFF_moveori == CONTROL_ON)
    {
        doubles tempQuat(4);
        for(int i=0;i<4;i++)
        {
            tempQuat[i] = sharedROS->R2P.wbik[tempNum].Goal_quat[i];
        }
        WBmotion->addPELOriInfo(tempQuat, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);
    }

    tempNum = RIGHT_ELBOW;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
        WBmotion->addRElbPosInfo(sharedROS->R2P.wbik[tempNum].Goal_angle, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);

    tempNum = LEFT_ELBOW;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
        WBmotion->addLElbPosInfo(sharedROS->R2P.wbik[tempNum].Goal_angle, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);

    tempNum = WAIST;
    if(sharedROS->R2P.wbik[tempNum].ONOFF_movepos == CONTROL_ON)
        WBmotion->addWSTPosInfo(sharedROS->R2P.wbik[tempNum].Goal_angle, sharedROS->R2P.wbik[tempNum].GoalmsTime/1000);

}



































/******************************************************************************************************/
void StartWBIKmotion(int _mode)
{
    WB_FLAG = false;
    usleep(10*1000);

    joint->RefreshToCurrentReference();

    WBmotion->ResetGlobalCoord(_mode);

    WBmotion->StopAll();

    WBmotion->RefreshToCurrentReference();

    joint->SetAllMotionOwner();

    WB_FLAG = true;
}

int CheckMotionOwned()
{
    for(int i=0;i<NO_OF_JOINTS;i++)
    {
        if(sharedCMD->MotionOwner[MC_ID_CH_Pairs[i].id][MC_ID_CH_Pairs[i].ch]!=PODO_NO)	return 0;
    }
    return 1;
}

int HasAnyOwnership()
{
    for(int i=0; i<NO_OF_JOINTS; i++)
    {
        if(sharedCMD->MotionOwner[MC_ID_CH_Pairs[i].id][MC_ID_CH_Pairs[i].ch] == PODO_NO)
            return true;
    }
    return false;
}

void CatchSignals(int _signal)
{
    switch(_signal)
    {
    case SIGHUP:
    case SIGINT:     // Ctrl-c
    case SIGTERM:    // "kill" from shell
    case SIGKILL:
    case SIGSEGV:
        isTerminated = -1;
        break;
    }
    usleep(1000*500);
}

int RBInitialize(void)
{
    // Block program termination
    isTerminated = 0;

    int shmFD;
    // Core Shared Memory Creation [Reference]==================================
    shmFD = shm_open(RBCORE_SHM_NAME_REFERENCE, O_RDWR, 0666);
    if(shmFD == -1)
    {
        FILE_LOG(logERROR) << "Fail to open core shared memory [Reference]";
        return false;
    }else
    {
        if(ftruncate(shmFD, sizeof(RBCORE_SHM_REFERENCE)) == -1)
        {
            FILE_LOG(logERROR) << "Fail to truncate core shared memory [Reference]";
            return false;
        }else
        {
            sharedREF = (pRBCORE_SHM_REFERENCE)mmap(0, sizeof(RBCORE_SHM_REFERENCE), PROT_WRITE, MAP_SHARED, shmFD, 0);
            if(sharedREF == (void*)-1)
            {
                FILE_LOG(logERROR) << "Fail to mapping core shared memory [Reference]";
                return false;
            }
        }
    }
    FILE_LOG(logSUCCESS) << "Core shared memory creation = OK [Reference]";
    // =========================================================================

    // Core Shared Memory Creation [Sensor]=====================================
    shmFD = shm_open(RBCORE_SHM_NAME_SENSOR, O_RDWR, 0666);
    if(shmFD == -1)
    {
        FILE_LOG(logERROR) << "Fail to open core shared memory [Sensor]";
        return false;
    }else{
        if(ftruncate(shmFD, sizeof(RBCORE_SHM_SENSOR)) == -1)
        {
            FILE_LOG(logERROR) << "Fail to truncate core shared memory [Sensor]";
            return false;
        }else
        {
            sharedSEN = (pRBCORE_SHM_SENSOR)mmap(0, sizeof(RBCORE_SHM_SENSOR), PROT_READ, MAP_SHARED, shmFD, 0);
            if(sharedSEN == (void*)-1)
            {
                FILE_LOG(logERROR) << "Fail to mapping core shared memory [Sensor]";
                return false;
            }
        }
    }
    FILE_LOG(logSUCCESS) << "Core shared memory creation = OK [Sensor]";
    // =========================================================================

    // Core Shared Memory Creation [Command]====================================
    shmFD = shm_open(RBCORE_SHM_NAME_COMMAND, O_RDWR, 0666);
    if(shmFD == -1){
        FILE_LOG(logERROR) << "Fail to open core shared memory [Command]";
        return false;
    }else{
        if(ftruncate(shmFD, sizeof(RBCORE_SHM_COMMAND)) == -1){
            FILE_LOG(logERROR) << "Fail to truncate core shared memory [Command]";
            return false;
        }else{
            sharedCMD = (pRBCORE_SHM_COMMAND)mmap(0, sizeof(RBCORE_SHM_COMMAND), PROT_READ|PROT_WRITE, MAP_SHARED, shmFD, 0);
            if(sharedCMD == (void*)-1){
                FILE_LOG(logERROR) << "Fail to mapping core shared memory [Command]";
                return false;
            }
        }
    }
    FILE_LOG(logSUCCESS) << "Core shared memory creation = OK [Command]";
    // =========================================================================


    // User Shared Memory Creation ============================================
    shmFD = shm_open(USER_SHM_NAME, O_RDWR, 0666);
    if(shmFD == -1){
        FILE_LOG(logERROR) << "Fail to open user shared memory";
        return -1;
    }else{
        if(ftruncate(shmFD, sizeof(USER_SHM)) == -1){
            FILE_LOG(logERROR) << "Fail to truncate user shared memory";
            return -1;
        }else{
            userData = (pUSER_SHM)mmap(0, sizeof(USER_SHM), PROT_READ|PROT_WRITE, MAP_SHARED, shmFD, 0);
            if(userData == (void*)-1){
                FILE_LOG(logERROR) << "Fail to mapping user shared memory";
                return -1;
            }
        }
    }
    FILE_LOG(logSUCCESS) << "User shared memory creation = OK";
    // =========================================================================

    // User Shared Memory Creation ============================================
    shmFD = shm_open(ROS_SHM_NAME, O_RDWR, 0666);
    if(shmFD == -1){
        FILE_LOG(logERROR) << "Fail to open ros shared memory";
        return -1;
    }else{
        if(ftruncate(shmFD, sizeof(ROS_SHM)) == -1){
            FILE_LOG(logERROR) << "Fail to truncate ros shared memory";
            return -1;
        }else{
            sharedROS = (pROS_SHM)mmap(0, sizeof(ROS_SHM), PROT_READ|PROT_WRITE, MAP_SHARED, shmFD, 0);
            if(sharedROS == (void*)-1){
                FILE_LOG(logERROR) << "Fail to mapping ros shared memory";
                return -1;
            }
        }
    }
    FILE_LOG(logSUCCESS) << "ROS shared memory creation = OK";
    // =========================================================================

    // Initialize internal joint classes =======================================
    joint = new JointControlClass(sharedREF, sharedSEN, sharedCMD, PODO_NO);
    joint->RefreshToCurrentReference();
    // =========================================================================


    // Create and start real-time thread =======================================
    if(rt_task_create(&rtFlagCon, "ROScommand_FLAG", 0, 95, 0) == 0){
        cpu_set_t aCPU;
        CPU_ZERO(&aCPU);
        CPU_SET(3, &aCPU);
        if(rt_task_set_affinity(&rtFlagCon, &aCPU) != 0){
            FILE_LOG(logWARNING) << "Flag real-time thread set affinity CPU failed..";
        }
        if(rt_task_start(&rtFlagCon, &RBFlagThread, NULL) == 0 ){
            FILE_LOG(logSUCCESS) << "Flag real-time thread start = OK";
        }else{
            FILE_LOG(logERROR) << "Flag real-time thread start = FAIL";
            return -1;
        }
    }else{
        FILE_LOG(logERROR) << "Fail to create Flag real-time thread";
        return -1;
    }

    if(rt_task_create(&rtTaskCon, "ROScommand_TASK", 0, 90, 0) == 0){
        cpu_set_t aCPU;
        CPU_ZERO(&aCPU);
        CPU_SET(2, &aCPU);
        if(rt_task_set_affinity(&rtTaskCon, &aCPU) != 0){
            FILE_LOG(logWARNING) << "Task real-time thread set affinity CPU failed..";
        }
        if(rt_task_start(&rtTaskCon, &RBTaskThread, NULL) == 0 ){
            FILE_LOG(logSUCCESS) << "Task real-time thread start = OK";
        }else{
            FILE_LOG(logERROR) << "Task real-time thread start = FAIL";
            return -1;
        }
    }else{
        FILE_LOG(logERROR) << "Fail to create Task real-time thread";
        return -1;
    }
    // =========================================================================
    return 0;
}

